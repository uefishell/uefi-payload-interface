# UEFIPayloadInterfaceRW
This is a base using PlyClaw UEFI Payload Exploit to create an NTOSKRNL UEFI Interface to execute kernel based functions

// 这是一个使用【PlyClaw UEFI】有效载荷漏洞创建【NTOSKRNL UEFI】接口以执行基于内核功能的基础。

# Contact
If you want to contact me in regards of my work or projects my discord is on my main github page / readme.md [i32-Sudo](https://github.com/i32-Sudo), Please do not message me for Issues or Learning/Studying I am not a teacher.
